<?PHP
$mod_strings['LBL_SQL_FIDDLE_ADMIN'] = 'SQL Fiddle';
$mod_strings['LBL_SQL_FIDDLE_ADMIN_DESCRIPTION'] = 'SQL Query Editor';
$mod_strings['LBL_SQL_FIDDLE_ADMIN_TITLE'] = 'SQL FIDDLE';
$mod_strings['SQL_FIDDLE_ADMIN_TITLE'] = 'SQL FIDDLE';
$mod_strings['SQL_FIDDLE_ADMIN_DESC'] = 'SQL Query Editor';
