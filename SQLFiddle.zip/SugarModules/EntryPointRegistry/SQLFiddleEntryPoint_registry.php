<?php

    $entry_point_registry['GetDbDetails'] = array(
        'file' => 'custom/include/SQLFiddle/get_db_details.php',
        'auth' => true
    );
